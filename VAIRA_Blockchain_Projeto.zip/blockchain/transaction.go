package main

type Transaction struct {
    From   string
    To     string
    Amount float64
    Note   string
}
